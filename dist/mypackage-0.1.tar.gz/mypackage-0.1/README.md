#- The top n items in an array.
This package will take an array as an input and return the top n numbers in an array in a descending order.
